<?php

namespace Modules\Demo\Repository\Contracts;

interface DummyRepositoryInterface
{
    public function getDummy();
}
