<?php

return [
    'test' => 'Test',
];
