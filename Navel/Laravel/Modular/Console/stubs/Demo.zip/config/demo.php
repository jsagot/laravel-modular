<?php

return [
    'aliases' => [
       'Dummy'=> Modules\Demo\Facades\Dummy::class,
    ]
];
