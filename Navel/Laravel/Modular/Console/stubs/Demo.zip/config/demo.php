<?php

return [
    'name' => 'demo',
    'aliases' => [
       'Dummy'=> Modules\Demo\Facades\Dummy::class,
    ]
];
