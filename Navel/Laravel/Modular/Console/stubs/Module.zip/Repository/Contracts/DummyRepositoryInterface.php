<?php

namespace Modules\{module}\Repository\Contracts;

interface DummyRepositoryInterface
{
    public function getDummy();
}
