<?php

return [
    'name' => '{moduleName}',
];
