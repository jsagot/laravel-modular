<?php

return [
    'aliases' => [
       //
    ]
];
